package com.qa.pageLayer;

import com.qa.testBase.TestBase;

public class ProductPage extends TestBase{

}
