package com.qa.pageLayer;

import com.qa.testBase.TestBase;

public class LoginPage extends TestBase {

}
